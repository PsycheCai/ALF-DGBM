function out = TraditionalSVRModel(xTrain, predStep, svrSetting)
%% ============================================================
% Traditional SVR model function
%
% Input:
% xTrain    : training sequence in current sliding window
% predStep  : prediction step, default is 1
% svrSetting: SVR settings
%
% Output:
% out.fitValues  : fitted values in the current window
% out.predValues : future predicted values
% out.fitMAPE    : fitting MAPE in the current window
% out.model      : trained SVR model
% out.param      : used SVR parameters
%
% Model:
% In each sliding window, the normalized time index is used as input:
%
%     t(k) -> x(k)
%
% Then the next normalized time index is used to predict x(n+1).
%
% This design is consistent with traditional trend extrapolation models.
%% ============================================================


%% ================== 1. Input processing ==================
xTrain = xTrain(:);
n = length(xTrain);

if nargin < 2 || isempty(predStep)
    predStep = 1;
end

if nargin < 3 || isempty(svrSetting)
    svrSetting = struct();
end

if n < 5
    error('Training window is too short for SVR. It is suggested that n >= 5.');
end


%% ================== 2. Default settings ==================
if ~isfield(svrSetting, 'kernelFunction')
    svrSetting.kernelFunction = 'gaussian';
end

if ~isfield(svrSetting, 'boxConstraint')
    svrSetting.boxConstraint = 10;
end

if ~isfield(svrSetting, 'epsilon')
    svrSetting.epsilon = 0.01;
end

if ~isfield(svrSetting, 'kernelScale')
    svrSetting.kernelScale = 'auto';
end

if ~isfield(svrSetting, 'standardizeX')
    svrSetting.standardizeX = true;
end

if ~isfield(svrSetting, 'standardizeY')
    svrSetting.standardizeY = true;
end

if ~isfield(svrSetting, 'useGridSearch')
    svrSetting.useGridSearch = false;
end

if ~isfield(svrSetting, 'boxList')
    svrSetting.boxList = [1, 10, 100];
end

if ~isfield(svrSetting, 'epsilonList')
    svrSetting.epsilonList = [0.001, 0.005, 0.01, 0.02];
end

if ~isfield(svrSetting, 'kernelScaleList')
    svrSetting.kernelScaleList = [0.2, 0.5, 1, 2];
end


%% ================== 3. Construct input and output data ==================
% Normalized time index
% Training interval: 0 to 1
tTrain = (0:n-1)' / (n-1);

% Prediction points outside the window
% One-step prediction: tPred = 1 + 1/(n-1)
tPred = (n:n+predStep-1)' / (n-1);

XTrain = tTrain;
XPred = tPred;

% Output standardization
if svrSetting.standardizeY
    yMean = mean(xTrain);
    yStd = std(xTrain);

    if yStd < eps
        yStd = 1;
    end

    yTrain = (xTrain - yMean) ./ yStd;
else
    yMean = 0;
    yStd = 1;
    yTrain = xTrain;
end


%% ================== 4. Train SVR model ==================
if svrSetting.useGridSearch

    [svrModel, bestParam] = train_svr_grid_search( ...
        XTrain, yTrain, xTrain, svrSetting, yMean, yStd);

else

    svrModel = fitrsvm( ...
        XTrain, yTrain, ...
        'KernelFunction', svrSetting.kernelFunction, ...
        'KernelScale', svrSetting.kernelScale, ...
        'BoxConstraint', svrSetting.boxConstraint, ...
        'Epsilon', svrSetting.epsilon, ...
        'Standardize', svrSetting.standardizeX);

    bestParam.kernelFunction = svrSetting.kernelFunction;
    bestParam.kernelScale = svrSetting.kernelScale;
    bestParam.boxConstraint = svrSetting.boxConstraint;
    bestParam.epsilon = svrSetting.epsilon;

end


%% ================== 5. Fitting and prediction ==================
fitNorm = predict(svrModel, XTrain);
predNorm = predict(svrModel, XPred);

fitValues = fitNorm .* yStd + yMean;
predValues = predNorm .* yStd + yMean;


%% ================== 6. Abnormal value treatment ==================
% This is only a numerical safeguard.
% It does not change normal prediction results.
if any(~isfinite(fitValues))
    fitValues(~isfinite(fitValues)) = xTrain(~isfinite(fitValues));
end

if any(~isfinite(predValues))
    predValues(~isfinite(predValues)) = xTrain(end);
end


%% ================== 7. Error calculation ==================
fitMAPE = local_mape(xTrain, fitValues);


%% ================== 8. Output ==================
out.fitValues = fitValues(:)';
out.predValues = predValues(:)';
out.fitMAPE = fitMAPE;
out.model = svrModel;
out.param = bestParam;
out.yMean = yMean;
out.yStd = yStd;

end


%% ============================================================
% Grid search for SVR parameters
%% ============================================================
function [bestModel, bestParam] = train_svr_grid_search(XTrain, yTrain, xOriginal, setting, yMean, yStd)

    bestModel = [];
    bestMAPE = inf;

    bestParam = struct();
    bestParam.kernelFunction = setting.kernelFunction;
    bestParam.kernelScale = NaN;
    bestParam.boxConstraint = NaN;
    bestParam.epsilon = NaN;

    for i = 1:length(setting.boxList)

        for j = 1:length(setting.epsilonList)

            for k = 1:length(setting.kernelScaleList)

                C = setting.boxList(i);
                epsValue = setting.epsilonList(j);
                ks = setting.kernelScaleList(k);

                try

                    tempModel = fitrsvm( ...
                        XTrain, yTrain, ...
                        'KernelFunction', setting.kernelFunction, ...
                        'KernelScale', ks, ...
                        'BoxConstraint', C, ...
                        'Epsilon', epsValue, ...
                        'Standardize', setting.standardizeX);

                    fitNorm = predict(tempModel, XTrain);
                    fitValue = fitNorm .* yStd + yMean;

                    tempMAPE = local_mape(xOriginal, fitValue);

                    if isfinite(tempMAPE) && tempMAPE < bestMAPE
                        bestMAPE = tempMAPE;
                        bestModel = tempModel;

                        bestParam.kernelFunction = setting.kernelFunction;
                        bestParam.kernelScale = ks;
                        bestParam.boxConstraint = C;
                        bestParam.epsilon = epsValue;
                    end

                catch
                    continue;
                end

            end

        end

    end

    if isempty(bestModel)
        error('SVR grid search failed. No valid SVR model was trained.');
    end

end


%% ============================================================
% MAPE calculation
%% ============================================================
function mapeValue = local_mape(realValue, predValue)

    realValue = realValue(:);
    predValue = predValue(:);

    denominator = max(abs(realValue), eps);

    mapeValue = mean(abs((realValue - predValue) ./ denominator)) * 100;

end
