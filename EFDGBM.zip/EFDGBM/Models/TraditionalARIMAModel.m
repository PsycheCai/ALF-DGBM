function out = TraditionalARIMAModel(xTrain, predStep, arimaSetting)
%% ============================================================
% Traditional ARIMA model function
%
% Input:
% xTrain      : training sequence in current sliding window
% predStep    : prediction step, default is 1
% arimaSetting: ARIMA settings
%
% Output:
% out.fitValues    : fitted values in the current window
% out.predValues   : future predicted values
% out.fitMAPE      : fitting MAPE in the current window
% out.order        : selected ARIMA order [p,d,q]
% out.icValue      : selected AIC or BIC value
% out.usedFallback : whether fallback prediction is used
%
% Model:
% ARIMA(p,d,q) is fitted in each sliding window.
% If autoSelectOrder = true, p,d,q are selected by AIC or BIC.
%% ============================================================


%% ================== 1. Input processing ==================
xTrain = xTrain(:);
n = length(xTrain);

if nargin < 2 || isempty(predStep)
    predStep = 1;
end

if nargin < 3 || isempty(arimaSetting)
    arimaSetting = struct();
end

if n < 6
    error('Training window is too short for ARIMA. It is suggested that n >= 6.');
end


%% ================== 2. Default settings ==================
if ~isfield(arimaSetting, 'autoSelectOrder')
    arimaSetting.autoSelectOrder = true;
end

if ~isfield(arimaSetting, 'pList')
    arimaSetting.pList = 0:2;
end

if ~isfield(arimaSetting, 'dList')
    arimaSetting.dList = 0:1;
end

if ~isfield(arimaSetting, 'qList')
    arimaSetting.qList = 0:2;
end

if ~isfield(arimaSetting, 'maxPQSum')
    arimaSetting.maxPQSum = 3;
end

if ~isfield(arimaSetting, 'icType')
    arimaSetting.icType = 'BIC';
end

if ~isfield(arimaSetting, 'fixedP')
    arimaSetting.fixedP = 1;
end

if ~isfield(arimaSetting, 'fixedD')
    arimaSetting.fixedD = 1;
end

if ~isfield(arimaSetting, 'fixedQ')
    arimaSetting.fixedQ = 0;
end

if ~isfield(arimaSetting, 'estimateConstant')
    arimaSetting.estimateConstant = true;
end

if ~isfield(arimaSetting, 'display')
    arimaSetting.display = 'off';
end


%% ================== 3. Estimate ARIMA model ==================
usedFallback = false;
icValue = inf;

try

    if arimaSetting.autoSelectOrder

        [EstMdl, selectedOrder, icValue] = select_arima_order(xTrain, arimaSetting);

    else

        p = arimaSetting.fixedP;
        d = arimaSetting.fixedD;
        q = arimaSetting.fixedQ;

        Mdl = make_arima_model(p, d, q, arimaSetting.estimateConstant);

        [EstMdl, ~, logL] = estimate(Mdl, xTrain, 'Display', arimaSetting.display);

        numParam = count_arima_params(p, q, arimaSetting.estimateConstant);
        numObs = max(n - d, 1);

        [aicValue, bicValue] = local_aicbic(logL, numParam, numObs);

        if strcmpi(arimaSetting.icType, 'AIC')
            icValue = aicValue;
        else
            icValue = bicValue;
        end

        selectedOrder = [p, d, q];

    end

    %% ================== 4. In-sample fitting values ==================
    % The residual-based fitted value is:
    % fitted = real value - innovation residual
    residuals = infer(EstMdl, xTrain);

    fitValues = xTrain - residuals;

    % Boundary treatment for first observations
    p = selectedOrder(1);
    d = selectedOrder(2);
    q = selectedOrder(3);

    startFix = max([1, p, d, q]);

    fitValues(1:startFix) = xTrain(1:startFix);

    % Replace abnormal fitted values if necessary
    invalidFit = ~isfinite(fitValues);
    fitValues(invalidFit) = xTrain(invalidFit);


    %% ================== 5. Future forecasting ==================
    predValues = forecast(EstMdl, predStep, 'Y0', xTrain);

    predValues = predValues(:);

    % If prediction is invalid, use fallback
    if any(~isfinite(predValues))
        usedFallback = true;
        predValues = fallback_forecast(xTrain, predStep);
    end

catch

    %% ================== 6. Fallback if ARIMA estimation fails ==================
    % In very short windows or unstable windows, ARIMA estimation may fail.
    % Then use random-walk fallback:
    % fitted value: x_hat(k) = x(k-1)
    % predicted value: x_hat(n+1) = x(n)
    usedFallback = true;

    selectedOrder = [NaN, NaN, NaN];
    icValue = NaN;

    fitValues = zeros(n, 1);
    fitValues(1) = xTrain(1);
    fitValues(2:end) = xTrain(1:end-1);

    predValues = fallback_forecast(xTrain, predStep);

end


%% ================== 7. Error calculation ==================
fitMAPE = local_mape(xTrain, fitValues);


%% ================== 8. Output ==================
out.fitValues = fitValues(:)';
out.predValues = predValues(:)';
out.fitMAPE = fitMAPE;
out.order = selectedOrder;
out.icValue = icValue;
out.usedFallback = usedFallback;

if exist('EstMdl', 'var')
    out.EstMdl = EstMdl;
else
    out.EstMdl = [];
end

end


%% ============================================================
% Select ARIMA order by AIC or BIC
%% ============================================================
function [bestMdl, bestOrder, bestIC] = select_arima_order(y, setting)

    y = y(:);
    n = length(y);

    bestMdl = [];
    bestOrder = [NaN, NaN, NaN];
    bestIC = inf;

    for p = setting.pList

        for d = setting.dList

            for q = setting.qList

                % Avoid too complex models for short windows
                if p + q > setting.maxPQSum
                    continue;
                end

                % Avoid too many parameters for very short samples
                numParam = count_arima_params(p, q, setting.estimateConstant);
                numObs = max(n - d, 1);

                if numObs <= numParam + 2
                    continue;
                end

                try

                    Mdl = make_arima_model(p, d, q, setting.estimateConstant);

                    [EstMdl, ~, logL] = estimate(Mdl, y, 'Display', setting.display);

                    [aicValue, bicValue] = local_aicbic(logL, numParam, numObs);

                    if strcmpi(setting.icType, 'AIC')
                        currentIC = aicValue;
                    else
                        currentIC = bicValue;
                    end

                    if isfinite(currentIC) && currentIC < bestIC
                        bestIC = currentIC;
                        bestMdl = EstMdl;
                        bestOrder = [p, d, q];
                    end

                catch
                    % Skip failed candidate model
                    continue;
                end

            end

        end

    end

    if isempty(bestMdl)
        error('No valid ARIMA model is selected.');
    end

end


%% ============================================================
% Create ARIMA model
%% ============================================================
function Mdl = make_arima_model(p, d, q, estimateConstant)

    Mdl = arima(p, d, q);

    if ~estimateConstant
        Mdl.Constant = 0;
    end

end


%% ============================================================
% Count estimated parameters
%% ============================================================
function numParam = count_arima_params(p, q, estimateConstant)

    % AR coefficients: p
    % MA coefficients: q
    % Variance: 1
    % Constant: 1 if estimated
    numParam = p + q + 1;

    if estimateConstant
        numParam = numParam + 1;
    end

end


%% ============================================================
% AIC and BIC calculation
%% ============================================================
function [aicValue, bicValue] = local_aicbic(logL, numParam, numObs)

    aicValue = -2 * logL + 2 * numParam;
    bicValue = -2 * logL + log(numObs) * numParam;

end


%% ============================================================
% Fallback forecast
%% ============================================================
function predValues = fallback_forecast(y, predStep)

    y = y(:);

    % Random-walk fallback
    predValues = repmat(y(end), predStep, 1);

end


%% ============================================================
% MAPE calculation
%% ============================================================
function mapeValue = local_mape(realValue, predValue)

    realValue = realValue(:);
    predValue = predValue(:);

    denominator = max(abs(realValue), eps);

    mapeValue = mean(abs((realValue - predValue) ./ denominator)) * 100;

end