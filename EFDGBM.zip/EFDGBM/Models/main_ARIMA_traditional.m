clear; clc; close all;

%% ============================================================
% Traditional ARIMA rolling one-step prediction
%
% Experiment design:
% 1. Use fixed-length sliding window.
% 2. Fit ARIMA model in each window.
% 3. Forecast the next value.
% 4. Slide the window by one point.
%
% Outputs:
% 1. Initial-window fitting MAPE
% 2. Mean sliding fitting MAPE
% 3. Rolling prediction MAPE
% 4. Original series and combined prediction series
%
% Note:
% This code uses mostly English labels to avoid encoding problems.
%% ============================================================


%% ================== 1. Data input ==================
x0 = xlsread('data_dianchi_nasa.xlsx','sheet1','e2:e133');
% xijiaodaȫ��ȥ�ף�b3:b390(ȥβ),c3:c408,d3:d393��ȥβ��,e3:e397,f3:f404,g3:g409,h3:h403,i3:i421
% nasa���ݣ�b2:b169,c2:c169,d2:d169,e2:e133,f2:f29,g2:g29,h2:h29,i2:i29
% ���β�ֵ�����ֵ��k2:k29,l2:l29,m2:29,n2:n29
% calce���ݣ�a2:a781,b2:b833,c2:c906,d2:d904
% Data cleaning
x0 = x0(:)';
x0 = x0(~isnan(x0));

N = length(x0);

fprintf('Series length N = %d\n', N);


%% ================== 2. Rolling-window setting ==================
% Sliding window length
winLen = 10;

% One-step prediction
predStep = 1;

if N <= winLen
    error('Series length must be larger than winLen.');
end

if winLen < 6
    error('ARIMA window length is too short. It is suggested that winLen >= 6.');
end


%% ================== 3. ARIMA setting ==================
arimaSetting = struct();

% Whether to automatically select ARIMA order in each window
% true  : search p,d,q and select by AIC or BIC
% false : use fixed p,d,q
arimaSetting.autoSelectOrder = true;

% Candidate order ranges for automatic selection
arimaSetting.pList = 0:2;
arimaSetting.dList = 0:1;
arimaSetting.qList = 0:2;

% Maximum p + q to avoid over-parameterization in short windows
arimaSetting.maxPQSum = 3;

% Information criterion: 'BIC' or 'AIC'
arimaSetting.icType = 'BIC';

% If autoSelectOrder = false, use this fixed ARIMA(p,d,q)
arimaSetting.fixedP = 1;
arimaSetting.fixedD = 1;
arimaSetting.fixedQ = 0;

% Whether to estimate the constant term
% true  : estimate constant term
% false : set constant term as 0
arimaSetting.estimateConstant = true;

% Display estimation process or not
arimaSetting.display = 'off';


%% ================== 4. Rolling prediction ==================
numRoll = N - winLen;

predIndex = zeros(numRoll, 1);
predValues = zeros(numRoll, 1);
realValues = zeros(numRoll, 1);

fitMAPE_eachWindow = zeros(numRoll, 1);

orderP = zeros(numRoll, 1);
orderD = zeros(numRoll, 1);
orderQ = zeros(numRoll, 1);
icValue = zeros(numRoll, 1);
usedFallback = false(numRoll, 1);

firstFit = [];
firstTrain = [];
firstOrder = [];

fprintf('\n==============================\n');
fprintf('Start ARIMA rolling prediction\n');
fprintf('==============================\n');

for i = 1:numRoll

    fprintf('Running window %d / %d ...\n', i, numRoll);

    % Current training window
    xTrain = x0(i : i + winLen - 1);

    % Real value to be predicted
    realNext = x0(i + winLen);

    % Call ARIMA model function
    modelOut = TraditionalARIMAModel(xTrain, predStep, arimaSetting);

    % Save fitting result of the first window
    if i == 1
        firstFit = modelOut.fitValues;
        firstTrain = xTrain;
        firstOrder = modelOut.order;
    end

    % Save rolling prediction result
    predIndex(i) = i + winLen;
    predValues(i) = modelOut.predValues(end);
    realValues(i) = realNext;

    % Save fitting MAPE of current window
    fitMAPE_eachWindow(i) = modelOut.fitMAPE;

    % Save selected ARIMA order
    orderP(i) = modelOut.order(1);
    orderD(i) = modelOut.order(2);
    orderQ(i) = modelOut.order(3);

    icValue(i) = modelOut.icValue;
    usedFallback(i) = modelOut.usedFallback;

end


%% ================== 5. Error calculation ==================
% Initial-window fitting error
initialFitMAPE = local_mape(firstTrain, firstFit);

% Mean sliding-window fitting error
meanFitMAPE = mean(fitMAPE_eachWindow);

% Rolling prediction error
predMAPE = local_mape(realValues, predValues);

fprintf('\n==============================\n');
fprintf('Traditional ARIMA results\n');
fprintf('==============================\n');
fprintf('Initial-window fitting MAPE = %.6f%%\n', initialFitMAPE);
fprintf('Mean sliding fitting MAPE   = %.6f%%\n', meanFitMAPE);
fprintf('Rolling prediction MAPE     = %.6f%%\n', predMAPE);
fprintf('First-window ARIMA order    = (%d,%d,%d)\n', firstOrder(1), firstOrder(2), firstOrder(3));
fprintf('Number of fallback windows  = %d\n', sum(usedFallback));


%% ================== 6. Construct combined series ==================
% The first winLen points are fitting values of the first window.
% The following points are rolling one-step prediction values.
combinedSeries = nan(1, N);
combinedSeries(1:winLen) = firstFit;

for i = 1:numRoll
    combinedSeries(predIndex(i)) = predValues(i);
end


%% ================== 7. Output tables ==================
Index = (1:N)';
Original = x0(:);
ARIMA_Combined = combinedSeries(:);

PredictionTable = table(Index, Original, ARIMA_Combined);

fprintf('\n==============================\n');
fprintf('Original series and ARIMA combined prediction series\n');
fprintf('The first winLen points are initial-window fitting values.\n');
fprintf('The following points are rolling prediction values.\n');
fprintf('==============================\n');
disp(PredictionTable);

MetricTable = table( ...
    {'ARIMA'}', ...
    initialFitMAPE, ...
    meanFitMAPE, ...
    predMAPE, ...
    sum(usedFallback), ...
    'VariableNames', {'Model', 'InitialFitMAPE', 'MeanFitMAPE', 'PredMAPE', 'FallbackCount'} ...
);

fprintf('\n==============================\n');
fprintf('Metric summary table\n');
fprintf('==============================\n');
disp(MetricTable);

Window = (1:numRoll)';
OrderTable = table( ...
    Window, ...
    predIndex, ...
    orderP, ...
    orderD, ...
    orderQ, ...
    realValues, ...
    predValues, ...
    fitMAPE_eachWindow, ...
    icValue, ...
    usedFallback, ...
    'VariableNames', {'Window', 'PredIndex', 'p', 'd', 'q', 'RealValue', 'PredValue', 'FitMAPE', 'IC', 'UsedFallback'} ...
);

fprintf('\n==============================\n');
fprintf('Selected ARIMA orders in each rolling window\n');
fprintf('==============================\n');
disp(OrderTable);


%% ================== 8. Plot original and combined series ==================
figure;
plot(1:N, x0, 'k-o', 'LineWidth', 1.6, 'MarkerSize', 5); hold on;
plot(1:N, combinedSeries, 'r--s', 'LineWidth', 1.3, 'MarkerSize', 4);

xlabel('Time index');
ylabel('Capacity / health indicator');
title('Traditional ARIMA rolling one-step prediction');
legend('Original series', 'ARIMA combined series', 'Location', 'best');
grid on;


%% ================== 9. Plot rolling prediction points ==================
figure;
plot(predIndex, realValues, 'k-o', 'LineWidth', 1.6, 'MarkerSize', 5); hold on;
plot(predIndex, predValues, 'r--s', 'LineWidth', 1.3, 'MarkerSize', 4);

xlabel('Prediction index');
ylabel('Capacity / health indicator');
title('Traditional ARIMA rolling prediction points');
legend('Real value', 'Predicted value', 'Location', 'best');
grid on;


%% ================== 10. Plot selected ARIMA orders ==================
figure;
plot(Window, orderP, '-o', 'LineWidth', 1.3, 'MarkerSize', 4); hold on;
plot(Window, orderD, '-s', 'LineWidth', 1.3, 'MarkerSize', 4);
plot(Window, orderQ, '-^', 'LineWidth', 1.3, 'MarkerSize', 4);

xlabel('Rolling window');
ylabel('Selected order');
title('Selected ARIMA orders in rolling windows');
legend('p', 'd', 'q', 'Location', 'best');
grid on;


%% ================== 11. Local MAPE function ==================
function mapeValue = local_mape(realValue, predValue)

    realValue = realValue(:);
    predValue = predValue(:);

    denominator = max(abs(realValue), eps);

    mapeValue = mean(abs((realValue - predValue) ./ denominator)) * 100;

end