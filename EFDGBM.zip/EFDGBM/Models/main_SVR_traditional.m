clear; clc; close all;

%% ============================================================
% Traditional SVR rolling one-step prediction
%
% Experiment design:
% 1. Use fixed-length sliding window.
% 2. Train an SVR model in each window.
% 3. Forecast the next value.
% 4. Slide the window by one point.
%
% Model:
% RBF kernel SVR is used.
% Input  : normalized time index in the current window
% Output : capacity / health indicator
%
% Outputs:
% 1. Initial-window fitting MAPE
% 2. Mean sliding-window fitting MAPE
% 3. Rolling prediction MAPE
% 4. Original series and combined prediction series
%
% Note:
% English comments are used to avoid encoding problems.
%% ============================================================


%% ================== 1. Data input ==================
x0 = xlsread('data_dianchi_nasa.xlsx','sheet1','e2:e133');
% xijiaodaȫ��ȥ�ף�b3:b390(ȥβ),c3:c408,d3:d393��ȥβ��,e3:e397,f3:f404,g3:g409,h3:h403,i3:i421
% nasa���ݣ�b2:b169,c2:c169,d2:d169,e2:e133,f2:f29,g2:g29,h2:h29,i2:i29
% ���β�ֵ�����ֵ��k2:k29,l2:l29,m2:29,n2:n29
% calce���ݣ�a2:a781,b2:b833,c2:c906,d2:d904
% Data cleaning
% Data cleaning
x0 = x0(:)';
x0 = x0(~isnan(x0));

N = length(x0);

fprintf('Series length N = %d\n', N);


%% ================== 2. Rolling-window setting ==================
% Sliding window length
winLen = 10;

% One-step prediction
predStep = 1;

if N <= winLen
    error('Series length must be larger than winLen.');
end

if winLen < 5
    error('SVR window length is too short. It is suggested that winLen >= 5.');
end


%% ================== 3. SVR setting ==================
svrSetting = struct();

% Kernel function: 'gaussian', 'linear', 'polynomial'
svrSetting.kernelFunction = 'gaussian';

% Box constraint C
svrSetting.boxConstraint = 10;

% Epsilon-insensitive loss parameter
svrSetting.epsilon = 0.01;

% Kernel scale
% 'auto' is convenient, but for very short windows it may be unstable.
% You can also set a numerical value, such as 0.5 or 1.
svrSetting.kernelScale = 'auto';

% Standardize input features
svrSetting.standardizeX = true;

% Standardize output y inside each window
% The model is trained on normalized y, then transformed back.
svrSetting.standardizeY = true;

% Whether to use a simple deterministic grid search for parameters
% false: use fixed parameters above
% true : search several C, epsilon and kernelScale values
svrSetting.useGridSearch = false;

% Candidate parameters if grid search is used
svrSetting.boxList = [1, 10, 100];
svrSetting.epsilonList = [0.001, 0.005, 0.01, 0.02];
svrSetting.kernelScaleList = [0.2, 0.5, 1, 2];

% Criterion for grid search
% Since each window is short, this code uses in-sample fitting MAPE.
% For strict validation, this can be changed to leave-one-out CV.
svrSetting.gridCriterion = 'FitMAPE';


%% ================== 4. Rolling prediction ==================
numRoll = N - winLen;

predIndex = zeros(numRoll, 1);
predValues = zeros(numRoll, 1);
realValues = zeros(numRoll, 1);

fitMAPE_eachWindow = zeros(numRoll, 1);

firstFit = [];
firstTrain = [];
firstParam = [];

fprintf('\n==============================\n');
fprintf('Start traditional SVR rolling prediction\n');
fprintf('==============================\n');

for i = 1:numRoll

    fprintf('Running window %d / %d ...\n', i, numRoll);

    % Current training window
    xTrain = x0(i : i + winLen - 1);

    % Real value to be predicted
    realNext = x0(i + winLen);

    % Call SVR model function
    modelOut = TraditionalSVRModel(xTrain, predStep, svrSetting);

    % Save fitting result of the first window
    if i == 1
        firstFit = modelOut.fitValues;
        firstTrain = xTrain;
        firstParam = modelOut.param;
    end

    % Save rolling prediction result
    predIndex(i) = i + winLen;
    predValues(i) = modelOut.predValues(end);
    realValues(i) = realNext;

    % Save fitting MAPE of current window
    fitMAPE_eachWindow(i) = modelOut.fitMAPE;

end


%% ================== 5. Error calculation ==================
% Initial-window fitting error
initialFitMAPE = local_mape(firstTrain, firstFit);

% Mean sliding-window fitting error
meanFitMAPE = mean(fitMAPE_eachWindow);

% Rolling prediction error
predMAPE = local_mape(realValues, predValues);

fprintf('\n==============================\n');
fprintf('Traditional SVR results\n');
fprintf('==============================\n');
fprintf('Initial-window fitting MAPE = %.6f%%\n', initialFitMAPE);
fprintf('Mean sliding fitting MAPE   = %.6f%%\n', meanFitMAPE);
fprintf('Rolling prediction MAPE     = %.6f%%\n', predMAPE);

fprintf('\nFirst-window SVR parameters:\n');
disp(firstParam);


%% ================== 6. Construct combined series ==================
% The first winLen points are fitting values of the first window.
% The following points are rolling one-step prediction values.
combinedSeries = nan(1, N);
combinedSeries(1:winLen) = firstFit;

for i = 1:numRoll
    combinedSeries(predIndex(i)) = predValues(i);
end


%% ================== 7. Output tables ==================
Index = (1:N)';
Original = x0(:);
SVR_Combined = combinedSeries(:);

PredictionTable = table(Index, Original, SVR_Combined);

fprintf('\n==============================\n');
fprintf('Original series and SVR combined prediction series\n');
fprintf('The first winLen points are initial-window fitting values.\n');
fprintf('The following points are rolling prediction values.\n');
fprintf('==============================\n');
disp(PredictionTable);

MetricTable = table( ...
    {'SVR'}', ...
    initialFitMAPE, ...
    meanFitMAPE, ...
    predMAPE, ...
    'VariableNames', {'Model', 'InitialFitMAPE', 'MeanFitMAPE', 'PredMAPE'} ...
);

fprintf('\n==============================\n');
fprintf('Metric summary table\n');
fprintf('==============================\n');
disp(MetricTable);

Window = (1:numRoll)';
WindowTable = table( ...
    Window, ...
    predIndex, ...
    realValues, ...
    predValues, ...
    fitMAPE_eachWindow, ...
    'VariableNames', {'Window', 'PredIndex', 'RealValue', 'PredValue', 'FitMAPE'} ...
);

fprintf('\n==============================\n');
fprintf('SVR rolling-window results\n');
fprintf('==============================\n');
disp(WindowTable);


%% ================== 8. Plot original and combined series ==================
figure;
plot(1:N, x0, 'k-o', 'LineWidth', 1.6, 'MarkerSize', 5); hold on;
plot(1:N, combinedSeries, 'r--s', 'LineWidth', 1.3, 'MarkerSize', 4);

xlabel('Time index');
ylabel('Capacity / health indicator');
title('Traditional SVR rolling one-step prediction');
legend('Original series', 'SVR combined series', 'Location', 'best');
grid on;


%% ================== 9. Plot rolling prediction points ==================
figure;
plot(predIndex, realValues, 'k-o', 'LineWidth', 1.6, 'MarkerSize', 5); hold on;
plot(predIndex, predValues, 'r--s', 'LineWidth', 1.3, 'MarkerSize', 4);

xlabel('Prediction index');
ylabel('Capacity / health indicator');
title('Traditional SVR rolling prediction points');
legend('Real value', 'Predicted value', 'Location', 'best');
grid on;


%% ================== 10. Local MAPE function ==================
function mapeValue = local_mape(realValue, predValue)

    realValue = realValue(:);
    predValue = predValue(:);

    denominator = max(abs(realValue), eps);

    mapeValue = mean(abs((realValue - predValue) ./ denominator)) * 100;

end